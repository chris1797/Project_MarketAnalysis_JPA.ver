package com.mac.model;

import org.springframework.stereotype.Component;

@Component
public class Board_VO {
	
	int num;
	String author;
	String title;
	String contents;
	java.sql.Date wdate;
	int pcode;

}
